const {chromium}=require('playwright');
const assert=require('node:assert/strict');
(async()=>{
 const browser=await chromium.launch({headless:true, executablePath:process.env.CHROME_PATH||undefined});const page=await browser.newPage({viewport:{width:1440,height:1100}});let errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.goto(process.env.DEMO_URL||'http://127.0.0.1:8878/versions/v8limit-merge/');await page.locator('#system-toggle').click();
 const dialog=()=>page.locator('dialog[open]').last();
 const close=async()=>dialog().locator('[data-action="close"]').first().click();
 const save=async()=>dialog().locator('button[type="submit"]').click();
 assert.equal(await page.locator('#system-main [data-action="roles"]').count(),0);
 await page.getByRole('button',{name:'新增账号',exact:true}).click();
 await dialog().locator('[name="name"]').fill('张员工');await dialog().locator('[name="phone"]').fill('13800000002');
 await dialog().locator('#account-org-picker summary').click();await dialog().locator('[data-action="choose-org"][data-ref="sh"]').click();
 await dialog().locator('#account-role-picker summary').click();await dialog().locator('[data-action="choose-role"][data-ref="staff"]').click();await save();
 assert.equal(await page.locator('#system-main tbody tr').count(),4);
 // Inline role creation survives account cancellation; role changes propagate to every binding.
 await page.getByRole('button',{name:'新增账号',exact:true}).click();await dialog().locator('#account-role-picker summary').click();await dialog().getByRole('button',{name:'＋ 新增自定义角色',exact:true}).click();
 await dialog().locator('[name="name"]').fill('车辆资料员');await dialog().locator('[name="desc"]').fill('维护车辆资料');await dialog().locator('[value="fleet.edit"]').check();await save();
 await dialog().locator('[data-action="choose-role"]').filter({hasText:'车辆资料员'}).click();await dialog().locator('[name="name"]').fill('张员工');await dialog().locator('[name="phone"]').fill('13800000002');await save();
 assert.equal(await page.locator('#system-main tbody tr').count(),5);
 await page.getByRole('button',{name:'新增账号',exact:true}).click();await dialog().locator('#account-role-picker summary').click();
 const option=dialog().locator('.v-option').filter({hasText:'车辆资料员'});await option.hover();await option.getByRole('button',{name:'编辑',exact:true}).click();await dialog().locator('[name="name"]').fill('车辆资料专员');await save();await close();
 assert.equal(await page.locator('#system-main').getByRole('button',{name:'车辆资料专员',exact:true}).count(),1);
 await page.getByRole('button',{name:'新增账号',exact:true}).click();await dialog().locator('#account-role-picker summary').click();const option2=dialog().locator('.v-option').filter({hasText:'车辆资料专员'});await option2.hover();await option2.getByRole('button',{name:'删除',exact:true}).click();assert.match(await dialog().innerText(),/1 条账号记录/);await save();await close();
 assert.match(await page.locator('#system-main tbody tr').last().innerText(),/—/);
 // Org cascade removal includes children, accounts and vehicles in one confirmation.
 await page.getByRole('button',{name:'新增账号',exact:true}).click();await dialog().locator('#account-org-picker summary').click();const org=dialog().locator('.v-option').filter({hasText:'上海'});await org.hover();await org.getByRole('button',{name:'删除',exact:true}).click();assert.match(await dialog().innerText(),/下级组织/);assert.match(await dialog().innerText(),/2 辆车/);await save();await close();
 await page.locator('#fleet-toggle').click();assert.equal(await page.locator('#main').getByText('上海 / 浦东店',{exact:true}).count(),0);
 await page.locator('#system-toggle').click();await page.getByLabel('当前集团').selectOption('second');assert.equal(await page.locator('#system-main tbody tr').count(),1);
 // NIO: common role list and credit-only management.
 await page.getByLabel('演示身份').selectOption('nio');await page.getByRole('button',{name:'角色管理',exact:true}).click();assert.equal(await dialog().locator('tbody tr').count(),3);await close();
 await page.getByRole('button',{name:'新增集团',exact:true}).click();await dialog().locator('[name="group"]').fill('测试集团');await dialog().locator('[name="credit"]').fill('91310000MA12345679');await dialog().getByRole('button',{name:'新增社会信用代码',exact:true}).click();await dialog().locator('[name="credit"]').last().fill('91310000MA12345670');await save();
 const group=page.locator('.v-group').filter({hasText:'测试集团'});await group.getByRole('button',{name:'企业管理',exact:true}).click();assert.equal(await dialog().locator('tbody tr').count(),2);assert.equal(await dialog().getByText('子公司',{exact:false}).count(),0);
 await dialog().getByRole('button',{name:'编辑',exact:true}).first().click();await dialog().locator('[name="credit"]').fill('91310000MA12345671');await save();await dialog().getByRole('button',{name:'删除',exact:true}).last().click();await save();assert.equal(await dialog().locator('tbody tr').count(),1);await close();
 await group.getByRole('button',{name:'查看组织',exact:true}).click();assert.equal(await dialog().getByRole('button',{name:'删除',exact:true}).count(),0);await close();
 await page.locator('#account-filter [name=q]').fill('91310000MA12345671');await page.locator('#account-filter button[type=submit], #account-filter button.primary').click();assert.equal(await page.locator('.v-group').count(),1);assert.match(await page.locator('.v-group').innerText(),/匹配的社会信用代码/);
 assert.deepEqual(errors,[]);await page.screenshot({path:'/tmp/v8-nio.png'});
 console.log('PASS: combination creation, inline roles, propagated edits, role/org deletion, fleet linkage, group isolation, NIO readonly, credits CRUD/search; no page errors');await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
