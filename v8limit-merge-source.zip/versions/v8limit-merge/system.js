(()=>{
'use strict';
const catalog=[['车队管理',[['fleet.view','查看车队','统计、查询、列表、车辆状态及驳回原因'],['fleet.add','新增车辆','填写资料、上传证明、提交审核'],['fleet.files','编辑车辆证件与照片','上传、预览、删除和识别'],['fleet.vin','编辑车辆 VIN','保存仍执行归属及重复校验'],['fleet.credit','编辑社会信用号','须与所属公司一致'],['fleet.edit','编辑车辆基础资料','车牌号、车型、颜色及公里数'],['fleet.company','编辑车辆所属公司','仅授权范围内公司'],['fleet.assign','分配车辆','所选车辆与目标组织均须在范围内']]],['账号管理',[['account.view','查看账号','列表及详情'],['account.edit','管理账号','新增、编辑、启用及停用'],['account.grant','分配角色','配置账号角色']]],['角色管理',[['role.view','查看角色','角色列表及关联账号'],['role.edit','管理角色','新增、复制、配置权限、启停用']]],['权限点',[['permission.view','查看权限点','只读权限目录']]],['组织管理',[['org.view','查看组织','组织树及详情'],['org.edit','管理组织','新增、删除']]],['企业管理',[['asset.view','查看企业','查询集团和社会信用代码'],['asset.edit','管理企业','维护集团和社会信用代码']]]];
function deps(k){if(k.startsWith('fleet.')&&k!=='fleet.view')return ['fleet.view'];if(k==='account.grant')return ['account.view','role.view'];if(k.endsWith('.edit'))return [k.replace('.edit','.view')];return []}
const $ = selector => document.querySelector(selector);
const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const key = 'fleet-v8limit-merge-permissions-1';
const home = 'example';
const id = () => crypto.randomUUID();
const active = '启用', disabled = '停用';
const demoPerms = ['fleet.view','fleet.add','fleet.edit','fleet.files','fleet.assign'];
const permLabels = new Map(catalog.flatMap(([,items]) => items.map(([code,name]) => [code,name])));
function initialState(){
  const allKeys=[...permLabels.keys()];
  const templates = [
    ['nio','NIO 超级管理员','维护集团、通用角色和权限点',allKeys.filter(code=>code!=='org.edit')],
    ['admin','集团超级管理员','管理本集团员工、角色和组织',allKeys.filter(code=>!code.startsWith('permission.')&&!code.startsWith('asset.'))],
    ['staff','门店员工','查看门店车辆',['fleet.view']]
  ];
  const group = (gid,name,company,credit) => ({
    id:gid,name, credits:[credit],
    orgs:[{id:'china',name:'中国',type:'根组织',parent:''}],
    accounts:[]
  });
  const sample=group(home,'示例出行集团','示例上海子公司','91310000MA12345678');
  sample.orgs.push({id:'sh',name:'上海',type:'中间组织',parent:'china'},{id:'pd',name:'浦东店',type:'门店',parent:'sh'});
  sample.accounts.push({id:'self',name:'集团管理员',phone:'13800000001',org:'china',roles:['admin'],status:active},
    {id:'store',name:'张员工',phone:'13800000002',org:'pd',roles:['staff'],status:active},
    {id:'staff1',name:'李员工',phone:'13800000003',org:'pd',roles:['staff'],status:active});
  const second=group('second','示例同城集团','','91330100MA87654321');
  second.accounts.push({id:'self-second',name:'集团管理员',phone:'13800000001',org:'china',roles:['admin'],status:active});
  return {groups:[sample,second],roles:templates.map(([rid,name,desc,perms])=>({id:rid,name,desc,perms:[...perms],status:active,group:null}))};
}
let data;
try { data=JSON.parse(localStorage.getItem(key)); } catch {}
if(!data?.groups||!data?.roles)data=initialState();
function persist(){localStorage.setItem(key,JSON.stringify(data));}
let currentGroup=home;
const currentPhone='13800000001';
const accessibleGroups=()=>data.groups.filter(g=>g.accounts.some(a=>a.phone===currentPhone&&a.status==='启用'));
let operator='group', page='fleet', expanded=new Set(), filters={}, query='';
const isNio=()=>operator==='nio';
const getGroup=gid=>data.groups.find(g=>g.id===gid);
const getRole=rid=>data.roles.find(r=>r.id===rid);
const superRole=rid=>['nio','admin'].includes(rid);
const rolesFor=group=>data.roles.filter(r=>r.group===null||r.group===group.id);
const tag=(value)=>'<span class="sys-tag">'+esc(value)+'</span>';
const button=(text,action,ref='',cls='')=>'<button type="button" data-action="'+action+'" data-ref="'+esc(ref)+'" class="'+cls+'">'+esc(text)+'</button>';
const field=(label,control)=>'<label class="v-field"><span>'+esc(label)+'</span>'+control+'</label>';
const input=(name,value='',attrs='')=>'<input name="'+name+'" value="'+esc(value)+'" '+attrs+'>';
const select=(name,items,value)=>'<select name="'+name+'">'+items.map(([v,label])=>'<option value="'+esc(v)+'" '+(v===value?'selected':'')+'>'+esc(label)+'</option>').join('')+'</select>';
const title=(name,actions='')=>'<div class="heading"><h1>'+name+'</h1><div class="actions">'+actions+'</div></div>';
const empty=text=>'<p class="v-empty">'+text+'</p>';
function table(head,rows){return '<div class="v-table"><table><thead><tr>'+head.map(h=>'<th>'+h+'</th>').join('')+'</tr></thead><tbody>'+rows.map(row=>'<tr>'+row.map(v=>'<td>'+v+'</td>').join('')+'</tr>').join('')+'</tbody></table></div>';}
const area=document.createElement('main');
area.id='system-main'; area.hidden=true; $('#shell').append(area);
function navigate(next){
  page=next==='points'&&!isNio()?'manage':next;
  renderGroupSwitch();
  $('#platform-toggle').hidden=!isNio();
  for(const [route,selector] of [['fleet','#fleet-toggle'],['manage','#system-toggle'],['points','#platform-toggle']]){
    const node=$(selector);node.classList.toggle('active',page===route);
    if(page===route)node.setAttribute('aria-current','page');else node.removeAttribute('aria-current');
  }
  $('#main').hidden=page!=='fleet';area.hidden=page==='fleet';
  if(page!=='fleet'){$('#drawer').hidden=true;$('#shell').classList.remove('has-drawer');render();}
}
$('#fleet-toggle').addEventListener('click',()=>navigate('fleet'));
$('#system-toggle').onclick=()=>navigate('manage');
$('#platform-toggle').onclick=()=>navigate('points');
$('#demo-identity').onchange=e=>{
  operator=e.target.value;expanded.clear();filters={};query='';
  document.querySelectorAll('dialog[open]').forEach(d=>d.close());
  navigate(page);
};
function accountTable(group){
  const accounts=group.accounts.filter(a=>{
    if(isNio())return true;
    let node=group.orgs.find(n=>n.id===a.org);
    while(filters.org&&node&&node.id!==filters.org)node=group.orgs.find(n=>n.id===node.parent);
    return (!filters.org||!!node)&&(!filters.role||a.roles.includes(filters.role))&&
      (!filters.status||a.status===filters.status)&&(!filters.q||[a.name,a.phone].some(v=>v.includes(filters.q)));
  });
  if(!accounts.length)return empty(group.accounts.length?'暂无符合条件的账号':'暂无员工账号');
  const headers=['姓名 / 手机号','所属集团','所属组织','角色','状态',...(!isNio()?['操作']:[])];
  return table(headers,accounts.map(a=>[
    '<b>'+esc(a.name)+'</b><small>'+esc(a.phone)+'</small>',esc(group.name),
    esc(orgPath(group,group.orgs.find(n=>n.id===a.org)))||'—',
    a.roles.map(rid=>button(getRole(rid)?.name||'—','role-info',rid,'sys-tag')).join(' ')||'—',
    esc(a.status),...(!isNio()?[button('编辑','edit-account',a.id,'link')]:[])
  ]));
}
function render(){
  document.title=(page==='points'?'权限点':'权限管理')+' · v8limit-merge';
  if(page==='points')return renderPoints();
  const local=getGroup(currentGroup);
  const actions=isNio()
    ?button('新增集团','add-group','','primary')+button('新增账号','add-account')+button('角色管理','roles')
    :button('新增账号','add-account','','primary');
  const prompt=isNio()?'集团名称或统一社会信用代码':'姓名或手机号';
  const keyword=input('q',filters.q,'aria-label="'+prompt+'" placeholder="'+prompt+'"');
  const picks=(name,label,items)=>select(name,[['',label],...items],filters[name]||'').replace('<select ','<select aria-label="'+label+'" ');
  const selectors=isNio()?'':picks('org','全部组织',local.orgs.map(n=>[n.id,orgPath(local,n)]))+
    picks('role','全部角色',rolesFor(local).map(r=>[r.id,r.name]))+
    picks('status','全部状态',[active,disabled,'待激活'].map(v=>[v,v]));
  const filter='<form class="sys-toolbar" id="account-filter">'+keyword+selectors+'<button class="primary">查询</button>'+button('重置','reset-search')+'</form>';
  const results=isNio()?data.groups.map(groupResult).join('')||empty('暂无符合条件的集团'):accountTable(local);
  area.innerHTML=title('权限管理',actions)+filter+results;
  $('#account-filter').onsubmit=e=>{
    e.preventDefault();filters=Object.fromEntries(new FormData(e.target));filters.q=filters.q.trim();expanded.clear();render();
  };
}
function matchedCompanies(group,term){
  return group.credits.filter(c=>c.toLowerCase().includes(term));
}
function companyLines(codes){return codes.map(c=>'<div class="sys-leaf">统一社会信用代码：'+esc(c)+'</div>').join('');}
function renderGroupSwitch(){
  const header=$('#operator-company');
  if(isNio()){header.textContent='NIO';return;}
  header.innerHTML=select('current-group',accessibleGroups().map(g=>[g.id,g.name]),currentGroup).replace('<select ','<select aria-label="当前集团" ');
  header.querySelector('select').onchange=e=>{currentGroup=e.target.value;filters={};expanded.clear();render();};
}
function groupResult(g){
  const term=(filters.q||'').toLowerCase(),matches=term?matchedCompanies(g,term):[];
  if(term&&!g.name.toLowerCase().includes(term)&&!matches.length)return '';
  const matchRows=matches.length?'<div class="v-matches"><small>匹配的社会信用代码</small>'+companyLines(matches)+'</div>':'';
  return '<section class="v-group"><header>'+button((expanded.has(g.id)?'▾　':'▸　')+g.name,'toggle-group',g.id,'group-name')+
    '<div class="actions">'+button('企业管理','company',g.id,'link')+button('查看角色','group-roles',g.id,'link')+button('查看组织','group-orgs',g.id,'link')+
    '</div></header>'+matchRows+(expanded.has(g.id)?accountTable(g):'')+'</section>';
}
function renderPoints(){
  const term=query.toLowerCase();
  const folders=catalog.map(([name,items])=>{
    const matches=items.filter(p=>(name+p.join(' ')).toLowerCase().includes(term));
    return !matches.length?'':'<details class="sys-folder" '+(term?'open':'')+'><summary>'+name+tag(matches.length+' 项')+'</summary><div class="sys-folder-children">'+matches.map(([code,label,desc])=>'<div class="sys-leaf"><b>'+label+'</b> <code>'+code+'</code><p>'+desc+'</p><small>依赖权限：'+(deps(code).map(k=>permLabels.get(k)).join('、')||'无')+'</small></div>').join('')+'</div></details>';
  }).join('');
  area.innerHTML=title('权限点')+'<form class="sys-toolbar" id="point-filter"><input aria-label="搜索权限点" name="q" placeholder="搜索权限名称、编码或说明" value="'+esc(query)+'"><button>查询</button>'+button('重置','reset-points')+'</form><section class="sys-panel">'+(folders||empty('暂无匹配权限点'))+'</section>';
  $('#point-filter').onsubmit=e=>{e.preventDefault();query=new FormData(e.target).get('q').trim();render();};
}
// Each child dialog returns to its parent. Refresh the parent only after a successful save.
function modal(name,body,save=null,after=null){
  const d=document.createElement('dialog');d.className='v-modal';d.setAttribute('aria-label',name);
  d.innerHTML='<header><h2>'+esc(name)+'</h2>'+button('×','close','','close')+'</header><form><section class="v-body">'+body+'</section><div role="alert" class="sys-error"></div><footer>'+button(save?'取消':'关闭','close')+(save?'<button class="primary" type="submit">保存</button>':'')+'</footer></form>';
  document.body.append(d);d.showModal();
  d.addEventListener('close',()=>d.remove(),{once:true});
  d.querySelector('form').onsubmit=e=>{
    e.preventDefault();if(!save)return;
    try{save(new FormData(e.target));persist();d.close();render();after?.();}
    catch(err){d.querySelector('[role="alert"]').textContent=err.message;}
  };
  d.onclick=e=>{if(e.target.closest('[data-action="close"]'))d.close();};
  return d;
}
function confirmDelete(title,message,remove,after){
  const d=modal(title,'<p class="v-warning">'+message+'</p>',()=>remove(),after);
  d.querySelector('button[type="submit"]').textContent='确认删除';
}
function deleteRole(role,after){
  if(superRole(role.id))return;
  if(isNio()?role.group!==null:role.group!==currentGroup)return;
  const affected=data.groups.flatMap(g=>g.accounts.filter(a=>a.roles.includes(role.id)));
  const message=affected.length?'该角色已关联 '+affected.length+' 条账号记录。删除后账号保留，角色显示“—”，原角色权限立即失效。确认删除？':'确认删除角色“'+esc(role.name)+'”？';
  confirmDelete('删除角色',message,()=>{
    affected.forEach(a=>a.roles=a.roles.filter(r=>r!==role.id));
    data.roles=data.roles.filter(r=>r.id!==role.id);
  },after);
}
function orgSubtree(group,node){
  const ids=new Set([node.id]);let size;
  do{size=ids.size;group.orgs.forEach(n=>{if(ids.has(n.parent))ids.add(n.id);});}while(size!==ids.size);
  return ids;
}
function deleteOrg(group,node,after){
  if(isNio()||node.id==='china')return;
  const ids=orgSubtree(group,node);
  const accounts=group.accounts.filter(a=>ids.has(a.org));
  const affectedNodes=group.orgs.filter(n=>ids.has(n.id));
  const vehicles=window.fleetOrgBridge?.linked(group.id,affectedNodes)||[];
  const reasons=['确认删除组织“'+esc(node.name)+'”？'];
  if(ids.size>1)reasons.push('将同时删除 '+(ids.size-1)+' 个下级组织。');
  if(accounts.length)reasons.push('关联 '+accounts.length+' 条账号记录（包含待激活及停用账号），删除后所属组织显示“—”，角色及状态不变。');
  if(vehicles.length)reasons.push('关联 '+vehicles.length+' 辆车，删除后对应城市／门店归属显示“—”。');
  confirmDelete('删除组织',reasons.join('<br>'),()=>{
    window.fleetOrgBridge?.clear(group.id,affectedNodes);
    accounts.forEach(a=>a.org='');group.orgs=group.orgs.filter(n=>!ids.has(n.id));
  },after);
}
function accountPickers(d,group,account,isAdmin){
  let selectedOrg=account?.org??'china',selectedRole=account?.roles[0]||'',trail=[];
  function lineage(nid){const chain=[];let n=group.orgs.find(n=>n.id===nid);while(n){chain.unshift(n.id);n=group.orgs.find(x=>x.id===n.parent);}return chain;}
  trail=lineage(selectedOrg);if(!trail.length)trail=['china'];
  const orgHost=d.querySelector('#account-org-picker'),roleHost=d.querySelector('#account-role-picker');
  function drawOrg(open=false){
    if(!group.orgs.some(n=>n.id===selectedOrg))selectedOrg='';
    trail=trail.filter(nid=>group.orgs.some(n=>n.id===nid));if(!trail.length)trail=['china'];
    const column=(nodes,parent)=>'<div class="v-picker-column">'+nodes.map(n=>'<div class="v-option '+(n.id===selectedOrg?'selected':'')+'">'+button(n.name,'choose-org',n.id,'v-option-label')+(n.id==='china'?'':button('删除','delete-org',n.id,'link hover-action'))+(group.orgs.some(x=>x.parent===n.id)?'<span aria-hidden="true">›</span>':'')+'</div>').join('')+(parent&&parent.type!=='门店'?button('＋ 新增组织','new-org',parent.id,'link'):'')+'</div>';
    let columns=column(group.orgs.filter(n=>!n.parent),null);
    for(const nid of trail){const n=group.orgs.find(x=>x.id===nid);if(n.type!=='门店')columns+=column(group.orgs.filter(x=>x.parent===nid),n);}
    orgHost.innerHTML='<span class="v-picker-label">所属组织</span>'+input('org',selectedOrg,'type="hidden"')+'<details class="v-picker" '+(open?'open':'')+'><summary>'+esc(orgPath(group,group.orgs.find(n=>n.id===selectedOrg))||'请选择组织')+'</summary><div class="v-cascade">'+columns+'</div></details>';
  }
  function drawRole(open=false){
    if(!getRole(selectedRole))selectedRole='';
    if(isAdmin){roleHost.innerHTML=field('角色',input('role',getRole('admin').name,'readonly'));return;}
    const roles=rolesFor(group).filter(r=>!superRole(r.id)&&(r.status===active||r.id===selectedRole));
    roleHost.innerHTML='<span class="v-picker-label">角色</span>'+input('role',selectedRole,'type="hidden"')+'<details class="v-picker" '+(open?'open':'')+'><summary>'+esc(getRole(selectedRole)?.name||'请选择角色')+'</summary><div class="v-role-options">'+roles.map(r=>'<div class="v-option '+(r.id===selectedRole?'selected':'')+'">'+button(r.name,'choose-role',r.id,'v-option-label')+tag(r.group===null?'通用':'自定义')+(r.group===group.id?button('编辑','edit-inline-role',r.id,'link hover-action')+button('删除','delete-inline-role',r.id,'link hover-action'):button('查看','view-inline-role',r.id,'link hover-action'))+'</div>').join('')+button('＋ 新增自定义角色','new-inline-role','','link')+'</div></details>';
  }
  drawOrg();drawRole();
  d.addEventListener('click',e=>{
    const b=e.target.closest('[data-action]');if(!b)return;const action=b.dataset.action,ref=b.dataset.ref;
    if(action==='choose-org'){selectedOrg=ref;trail=lineage(ref);drawOrg(group.orgs.find(n=>n.id===ref).type!=='门店');}
    if(action==='new-org')orgForm(group,group.orgs.find(n=>n.id===ref),'below',()=>drawOrg(true));
    if(action==='delete-org')deleteOrg(group,group.orgs.find(n=>n.id===ref),()=>drawOrg(true));
    if(action==='choose-role'){selectedRole=ref;drawRole();}
    if(action==='new-inline-role')roleForm(group,null,false,()=>drawRole(true));
    if(action==='edit-inline-role')roleForm(group,getRole(ref),false,()=>drawRole(true));
    if(action==='view-inline-role')roleForm(group,getRole(ref),true);
    if(action==='delete-inline-role')deleteRole(getRole(ref),()=>drawRole(true));
  });
}

function accountForm(group,a){
  const makeAdmin=isNio();
  if(makeAdmin&&a)return;
  const admin=a?.roles.includes('admin');
  let body=field('姓名',input('name',a?.name,'required maxlength="40" '+(a?'readonly':'')))+field('手机号',input('phone',a?.phone,'required type="tel" pattern="1[0-9]{10}" '+(a?'readonly':'')));
  if(makeAdmin)body+=field('角色',input('role',getRole('admin').name,'readonly'))+field('所属集团',select('group',data.groups.map(g=>[g.id,g.name]),group.id));
  else body+='<div id="account-org-picker"></div><div id="account-role-picker"></div>';
  if(a)body+=field('状态',select('status',[active,disabled,...(a.status==='待激活'?['待激活']:[])].map(s=>[s,s]),a.status));
  const d=modal(a?'编辑账号':'新增账号',body,fd=>{
    const target=makeAdmin?getGroup(fd.get('group')):group;
    const name=String(fd.get('name')).trim(),phone=String(fd.get('phone')).trim();
    if(!target||!name||!/^1\d{10}$/.test(phone))throw Error('请填写姓名、有效手机号及所属集团');
    if(data.groups.some(g=>g.accounts.some(x=>x.phone===phone&&x.name!==name)))throw Error('该手机号已有关联账号，请使用相同姓名');
    const roles=makeAdmin||admin?['admin']:[fd.get('role')];
    if(!roles.length||(!makeAdmin&&!admin&&roles.some(r=>!rolesFor(group).some(x=>x.id===r&&x.status===active&&!superRole(x.id)))))throw Error('请选择可分配的角色');
    const org=makeAdmin?'china':fd.get('org');
    if(!target.orgs.some(n=>n.id===org))throw Error('请选择所属组织');
    if(target.accounts.some(x=>x.id!==a?.id&&x.phone===phone&&x.org===org&&x.roles.length===roles.length&&x.roles.every(r=>roles.includes(r))))throw Error('该账号已有相同的组织与角色组合');
    const status=a?fd.get('status'):(target.accounts.find(x=>x.phone===phone)?.status||'待激活');
    if(admin&&a.status===active&&status!==active&&!group.accounts.some(x=>x.id!==a.id&&x.status===active&&x.roles.includes('admin')))throw Error('需保留至少一名启用的集团超管');
    const record={id:a?.id||id(),name,phone,roles,status,org};
    if(a)Object.assign(a,record);else target.accounts.push(record);
  });
  if(!makeAdmin)accountPickers(d,group,a,admin);
}
function roleForm(group,role,readonly,after){
  const creating=!role;
  const common=creating?isNio():role.group===null;
  const perms=role?.perms||[];
  const controls=readonly?'readonly':'required';
  const choices=[...new Set([...demoPerms,...perms])];
  const body=field('角色名称',input('name',role?.name,controls+' maxlength="40"'))+
    field('描述','<textarea name="desc" maxlength="200" '+(readonly?'readonly':'')+'>'+esc(role?.desc)+'</textarea>')+
    field('类型',input('type',common?'通用角色':'自定义角色','readonly'))+
    (creating?'':field('状态',readonly?input('status',role.status,'readonly'):select('status',[[active,active],[disabled,disabled]],role.status)))+
    '<fieldset><legend>'+(creating?'权限配置':'已有权限')+'</legend>'+choices.map(code=>'<label class="sys-check"><input name="perms" type="checkbox" value="'+esc(code)+'" '+(perms.includes(code)?'checked':'')+' '+(readonly?'disabled':'')+'>'+esc(permLabels.get(code)||code)+'</label>').join('')+'</fieldset>'+
    '<p class="sys-muted">车队管理权限仅作示意，完整可选权限点稍后补充。</p>';
  modal(creating?'新增角色':'角色详情',body,readonly?null:fd=>{
    const name=String(fd.get('name')).trim(),owner=common?null:group.id;
    if(!name)throw Error('请输入角色名称');
    if(data.roles.some(r=>r.id!==role?.id&&r.name===name&&(r.group===owner||r.group===null||common)))throw Error('角色名称已存在');
    if(!common&&/超管|超级管理员/.test(name))throw Error('集团不可新增超管角色');
    const selected=fd.getAll('perms');if(selected.some(k=>k.startsWith('fleet.')&&k!=='fleet.view')&&!selected.includes('fleet.view'))selected.unshift('fleet.view');
    if(role&&superRole(role.id)&&fd.get('status')!==active)throw Error('系统保留角色不可停用');
    const values={name,desc:fd.get('desc').trim(),status:creating?active:fd.get('status'),perms:selected};
    if(role)Object.assign(role,values);else data.roles.push({id:id(),group:owner,...values});
  },after);
}
function roleList(group,readOnly=false){
  const platform=isNio()&&!group;
  const d=modal(readOnly?'查看角色':'角色管理','');
  function refresh(){
    const roles=platform?data.roles.filter(r=>r.group===null):rolesFor(group);
    d.querySelector('.v-body').innerHTML=(readOnly?'':'<div class="v-tools">'+button('新增角色','new-role','','primary')+'</div>')+table(['角色名称','类型','描述','状态','操作'],roles.map(r=>[
      esc(r.name),tag(r.group===null?'通用角色':'自定义角色'),esc(r.desc)||'—',esc(r.status),button(readOnly?'详情':'编辑','role-detail',r.id,'link')+(!readOnly&&!superRole(r.id)?button('删除','delete-role',r.id,'link hover-action'):'')]));
  }
  refresh();d.addEventListener('click',e=>{
    const b=e.target.closest('[data-action]');if(!b)return;
    if(b.dataset.action==='new-role'&&!readOnly)roleForm(group,null,false,refresh);
    if(b.dataset.action==='delete-role'&&!readOnly)deleteRole(getRole(b.dataset.ref),refresh);
    if(b.dataset.action==='role-detail'){
      const r=getRole(b.dataset.ref);roleForm(group,r,readOnly||(!platform&&r.group===null),refresh);
    }
  });
}
function orgPath(group,node){
  const labels=[];
  while(node){labels.unshift(node.name);node=group.orgs.find(n=>n.id===node.parent);}
  return labels.join(' / ');
}
function orgForm(group,node,mode,after){
  if(isNio())return;
  if(mode==='above'&&!node.parent||mode==='below'&&node.type==='门店')return;
  const edit=mode==='edit', parent=mode==='below'?node.id:node.parent;
  const types=mode==='above'||(edit&&group.orgs.some(n=>n.parent===node.id))?['中间组织']:['中间组织','门店'];
  const body=field('组织名称',input('name',edit?node.name:'','required maxlength="40"'))+
    field('组织类型',select('type',types.map(t=>[t,t]),edit?node.type:types[0]))+
    field('上级组织',input('parent',group.orgs.find(n=>n.id===parent)?.name,'readonly'));
  modal(edit?'编辑组织':mode==='above'?'新增上级':'新增下级',body,fd=>{
    const name=fd.get('name').trim(),type=fd.get('type');
    if(!name)throw Error('请输入组织名称');
    if(group.orgs.some(n=>n.id!==(edit?node.id:'')&&n.parent===parent&&n.name===name))throw Error('同级组织名称已存在');
    if(edit)Object.assign(node,{name,type});
    else{
      const newNode={id:id(),name,type,parent};group.orgs.push(newNode);
      if(mode==='above')node.parent=newNode.id;
    }
  },after);
}
function treeMenu(d,element,x,y,actions,handler){
  d.querySelector('.v-context')?.remove();
  if(!actions.length)return;
  const menu=document.createElement('div');menu.className='v-context';menu.setAttribute('role','menu');
  menu.innerHTML=actions.map(([key,label])=>button(label,key)).join('');
  d.append(menu);const rect=element.getBoundingClientRect();
  menu.style.left=Math.min(x??rect.left,innerWidth-menu.offsetWidth-8)+'px';
  menu.style.top=Math.min(y??rect.bottom,innerHeight-menu.offsetHeight-8)+'px';
  menu.onclick=e=>{const b=e.target.closest('button');if(b){menu.remove();handler(b.dataset.action);}};
  menu.querySelector('button').focus();
}
function orgList(group){
  const draw=n=>'<li><div class="v-node">'+esc(n.name)+tag(n.type)+'</div><ul>'+group.orgs.filter(x=>x.parent===n.id).map(draw).join('')+'</ul></li>';
  modal('查看组织','<ul class="v-tree">'+draw(group.orgs.find(n=>n.id==='china'))+'</ul>');
}
function validateCredit(raw,old){
  const credit=raw.trim().toUpperCase();
  if(!/^[0-9A-HJ-NPQRTUWXY]{18}$/.test(credit))throw Error('请输入有效的 18 位统一社会信用代码');
  if(credit!==old&&data.groups.some(g=>g.credits.includes(credit)))throw Error('统一社会信用代码已存在');
  return credit;
}
function addGroup(){
  if(!isNio())return;
  const entry=()=>'<div class="v-code-entry">'+field('统一社会信用代码',input('credit','','required maxlength="18"'))+button('移除','remove-entry','','link')+'</div>';
  const d=modal('新增集团',field('集团名称',input('group','','required maxlength="60"'))+
    '<div class="v-tools"><strong>集团社会信用代码</strong>'+button('新增社会信用代码','append-entry','','link')+'</div><div class="v-company-entries">'+entry()+'</div>',fd=>{
    const name=fd.get('group').trim(),credits=fd.getAll('credit').map(c=>validateCredit(c));
    if(!name||data.groups.some(g=>g.name===name))throw Error('请输入唯一的集团名称');
    if(new Set(credits).size!==credits.length)throw Error('统一社会信用代码重复');
    data.groups.push({id:id(),name,credits,orgs:[{id:'china',name:'中国',type:'根组织',parent:''}],accounts:[]});
  });
  const list=d.querySelector('.v-company-entries');
  const sync=()=>list.querySelectorAll('[data-action="remove-entry"]').forEach(b=>b.hidden=list.children.length===1);
  d.addEventListener('click',e=>{
    const action=e.target.closest('button')?.dataset.action;
    if(action==='append-entry')list.insertAdjacentHTML('beforeend',entry());
    if(action==='remove-entry'&&list.children.length>1)e.target.closest('.v-code-entry').remove();
    sync();
  });sync();
}
function companyList(group){
  if(!isNio())return;
  const d=modal('企业管理','');
  function refresh(){d.querySelector('.v-body').innerHTML='<h3>'+esc(group.name)+'</h3><div class="v-tools">'+button('新增社会信用代码','add-code','','primary')+'</div>'+table(['统一社会信用代码','操作'],group.credits.map(c=>[esc(c),button('编辑','edit-code',c,'link')+button('删除','delete-code',c,'link')]));}
  refresh();d.addEventListener('click',e=>{
    const b=e.target.closest('[data-action]');if(!b)return;
    const code=b.dataset.ref;
    if(['add-code','edit-code'].includes(b.dataset.action))modal(code?'编辑社会信用代码':'新增社会信用代码',field('统一社会信用代码',input('credit',code,'required maxlength="18"')),fd=>{
      const value=validateCredit(fd.get('credit'),code);
      if(code)group.credits[group.credits.indexOf(code)]=value;else group.credits.push(value);
    },refresh);
    if(b.dataset.action==='delete-code')confirmDelete('删除社会信用代码','确认删除 '+esc(code)+'？',()=>{group.credits=group.credits.filter(c=>c!==code);},refresh);
  });
}
area.onclick=e=>{
  const b=e.target.closest('[data-action]');if(!b)return;
  const ref=b.dataset.ref,local=getGroup(currentGroup),group=getGroup(ref);
  switch(b.dataset.action){
    case 'add-account': accountForm(local);break;
    case 'edit-account': if(!isNio())accountForm(local,local.accounts.find(a=>a.id===ref));break;
    case 'role-info':roleForm(null,getRole(ref),true);break;
    case 'roles':roleList(isNio()?null:local);break;
    case 'orgs':if(!isNio())orgList(local,false);break;
    case 'add-group':addGroup();break;
    case 'toggle-group':if(isNio()){expanded.has(ref)?expanded.delete(ref):expanded.add(ref);render();}break;
    case 'company':if(isNio())companyList(group);break;
    case 'group-roles':if(isNio())roleList(group,true);break;
    case 'group-orgs':if(isNio())orgList(group,true);break;
    case 'reset-search':filters={};expanded.clear();render();break;
    case 'reset-points':query='';render();break;
  }
};
navigate('fleet');
})();