"""Update only the v8 payload; keep all existing version payloads unchanged."""
from pathlib import Path
import base64, gzip, json, re
root=Path(__file__).resolve().parents[1]
source=root/'versions/v8limit-merge'
html=(source/'index.html').read_text()
html=html.replace('<link rel="stylesheet" href="system.css">','<style>'+ (source/'system.css').read_text()+'</style>')
html=html.replace('<script src="system.js"></script>','<script>'+ (source/'system.js').read_text()+'</script>')
p=root/'index.html';page=p.read_text()
m=re.search(r'(<script[^>]*id="versions"[^>]*>)(.*?)(</script>)',page,re.S)
entries=json.loads(m[2]);old=entries.copy()
entries['v8limit-merge']=base64.b64encode(gzip.compress(html.encode(),mtime=0)).decode()
assert all(entries[k]==v for k,v in old.items() if k!='v8limit-merge')
page=page[:m.start(2)]+json.dumps(entries,ensure_ascii=False,separators=(',',':'))+page[m.end(2):]
page=page.replace('<a class="latest" href="?version=v7limit">打开最新版本 · v7limit</a>','<a class="latest" href="?version=v8limit-merge">打开最新版本 · v8limit-merge</a>')
if '<b>v8limit-merge</b>' not in page:
    page=page.replace('<article>','<article><a href="?version=v8limit-merge"><b>v8limit-merge</b><span>账号内管理组织与角色</span><i>打开 →</i></a>',1)
p.write_text(page)
print('v8 built; all previous version payloads unchanged')
